# D&D Game Sound Assets - Core Set (★)

This package contains **61 core (starred) sound files** mapped and renamed to your exact structure.

## Sources (all CC0 / Public Domain)
- **Kenney.nl RPG Audio** (via OpenGameArt): https://opengameart.org/content/50-rpg-sound-effects
  - Footsteps, UI clicks/doors, coins, knife/slice, cloth, creaks
- **rubberduck 80 CC0 RPG SFX**: https://opengameart.org/content/80-cc0-rpg-sfx
  - Blades, creatures (die/hurt/roar/slime), coins, gems, spells/fire, metal, wood, etc.

## Notes
- Many mappings are **reasonable approximations** from limited available free packs (e.g. generic footsteps used for dirt/stone/wood/grass/sand/snow/metal/water/lava; spell sounds reused for types).
- **Music** and most **ambience** are missing — need dedicated packs (Tallbeard CC0 Music Loop Bundle on itch.io is excellent and free).
- Unique weapon sounds, most individual spells, and non-starred files are not yet included.
- All files are MP3 for broad compatibility.
- No attribution required (CC0), but crediting Kenney.nl and rubberduck is appreciated.

## Next steps recommended
1. Download Kenney full audio packs from https://kenney.nl/assets?q=audio (UI Audio, Impact Sounds, etc.)
2. Tallbeard Music: https://tallbeard.itch.io/music-loop-bundle (CC0, hundreds of loops)
3. Search Freesound.org with "CC0" filter for specific missing SFX (e.g. "sword swing", "potion drink", "lava sizzle")
4. TomMusic free Fantasy SFX on itch.io for more polished combat/footsteps

I can continue sourcing and filling the remaining files if you want.
